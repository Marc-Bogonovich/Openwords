package com.openwords.view;

import com.example.openwords.R;

import android.app.Activity;
import android.os.Bundle;

public class SettingsPage extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_words_page);
	}
}
