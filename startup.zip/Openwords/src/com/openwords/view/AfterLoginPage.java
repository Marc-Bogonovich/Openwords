package com.openwords.view;

import com.example.openwords.R;

import android.os.Bundle;
import android.provider.Contacts.Settings;
import android.app.Activity;
import android.view.Menu;

public class AfterLoginPage extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_after_login_page);
		
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.after_login_page, menu);
		return true;
	}

}
