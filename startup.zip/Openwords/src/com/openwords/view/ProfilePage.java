package com.openwords.view;

public class ProfilePage {

}
