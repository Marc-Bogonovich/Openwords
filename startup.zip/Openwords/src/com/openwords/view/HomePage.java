package com.openwords.view;

import java.util.ArrayList;

import com.example.openwords.R;

import android.os.Bundle;
import android.provider.Contacts.Settings;
import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.app.ActionBar.OnNavigationListener;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;

public class HomePage extends ActionBarActivity implements OnClickListener {
	
	private Spinner begin, language;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_home_page);
		ActionBar actionBar = getActionBar();
		actionBar.setDisplayShowHomeEnabled(false);
		actionBar.setDisplayShowTitleEnabled(false);
		addItemsOnBegin();
		addItemsOnLanguage();
		
		
	}

	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
	    // Inflate the menu items for use in the action bar
	    MenuInflater inflater = getMenuInflater();
	    inflater.inflate(R.menu.home_page, menu);
	    return super.onCreateOptionsMenu(menu);
	}

	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
	    // Handle item selection
	    switch (item.getItemId()) {
	        case R.id.homePage_item_home:
	            Log.d("Icon click","Home icon clicks");
	            return true;
	        case R.id.homePage_item_words:
	        	Log.d("Icon click","Word icon clicks");
	            return true;
	        case R.id.homePage_item_stats:
	        	Log.d("Icon click","Stats icon clicks");
	            return true;
	        case R.id.homePage_item_profile:
	        	Log.d("Icon click","Profile icon clicks");
	        	profileButtonClick();
	            return true;
	        case R.id.homePage_item_settings:
	        	Log.d("Icon click","Setting icon clicks");
	            return true;
	        case R.id.homePage_item_tutorial:
	        	Log.d("Icon click","Tutorial icon clicks");
	            return true;
	        case R.id.homePage_item_logout:
	        	Log.d("Icon click","Logout icon clicks");
	            return true;
	        default:
	            return super.onOptionsItemSelected(item);
	    }
	}
	
	
	public void addItemsOnBegin() {
		begin = (Spinner) findViewById(R.id.homePage_Spinner_begin);
		ArrayAdapter<CharSequence> beginAdapter = ArrayAdapter.createFromResource(this, R.array.homePage_spinner_begin_array, android.R.layout.simple_spinner_item);
		beginAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		begin.setAdapter(beginAdapter);
	}
	
	public void addItemsOnLanguage() {
		language = (Spinner) findViewById(R.id.homePage_Spinner_chooseLanguage);
		ArrayAdapter<CharSequence> languageAdapter = ArrayAdapter.createFromResource(this, R.array.homePage_Spinner_language_array, android.R.layout.simple_spinner_item);
		languageAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		language.setAdapter(languageAdapter);
	}
	
	public void profileButtonClick() {
		HomePage.this.startActivity(new Intent(HomePage.this, ProfilePage.class));
	}


	@Override
	public void onClick(DialogInterface dialog, int which) {
		// TODO Auto-generated method stub
		
	}
	

}
