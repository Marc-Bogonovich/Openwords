package com.openwords.view;

import java.util.Calendar;

import com.example.openwords.R;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.util.Log;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.*;
import android.widget.*;

public class MainActivity extends Activity {
	Calendar c = Calendar.getInstance(); 
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		

//		Button pushMe_start_activity_button_loginPageGo = (Button) findViewById(R.id.pushMe_start_activity_button_loginPageGo);
//		pushMe_start_activity_button_loginPageGo.setOnClickListener(this);
//		
		lift_word_from_buttom(R.id.flashword_string_homePageLift01,200);
		lift_word_from_buttom(R.id.flashword_string_homePageLift02,150);
		lift_word_from_buttom(R.id.flashword_string_homePageLift03,350);
		lift_word_from_buttom(R.id.flashword_string_homePageLift04,100);
		lift_word_from_buttom(R.id.flashword_string_homePageLift05,260);
		lift_word_from_buttom(R.id.flashword_string_homePageLift06,400);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	private void lift_word_from_buttom(int stringName, int distance) {
		TextView word = (TextView) findViewById(stringName);	
		Animation animation = new TranslateAnimation(0, 0, 50, (-1*distance));
		animation.setDuration(5000); 
	    word.startAnimation(animation);  // start animation 
	    animation.setFillAfter(true);
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
	    Log.i("clicks","You Clicked screen");
	    loginButtonClick();
	    return super.onTouchEvent(event); 
	}
	
	
	
//	@Override
//	public void onClick(View v) {
//		// TODO Auto-generated method stub
//		 Log.i("clicks","You Clicked B1");
//		 switch(v.getId()) {
//		 case R.id.pushMe_start_activity_button_loginPageGo:
//			 loginButtonClick();
//			 break;
//		 }
//	}
	
	private void loginButtonClick() {
		Intent loginPageIntent = new Intent(MainActivity.this, LoginPage.class);
		MainActivity.this.startActivity(loginPageIntent);
	}
	

}
